﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _100pB
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string networkIP = getNetworkIP();
            string broadcastIP = getBroadcastIP(networkIP);
            int availableIPCount = getAvailableIPCount();
            textBox2.Text = networkIP;
            textBox3.Text = broadcastIP;
            textBox4.Text = availableIPCount.ToString();
        }

        public string getNetworkIP()
        {
            string data = textBox1.Text;
            string[] dataSplit = data.Split('/');
            string ip = dataSplit[0];
            int hostBits = Convert.ToInt32(dataSplit[1]);
            string convertIPtoBit = "";
            for (int i = 0; i < 4; i++)
            {
                string[] ipArray = ip.Split('.');
                int number = Convert.ToInt32(ipArray[i]);
                string ConvertToBit = Convert.ToString(number, 2).PadLeft(8, '0');
                convertIPtoBit += ConvertToBit;
            }
            string newIPtoBit = convertIPtoBit.Substring(0, hostBits).PadRight(32, '0');
            string networkIP = "";
            for (int i = 0; i < 4; i++)
            {
                string substr = newIPtoBit.Substring(i * 8, 8);
                int number = Convert.ToInt32(substr, 2);
                networkIP += number + (i == 3 ? "" : ".");
            }
            return networkIP;
        }
        public string getBroadcastIP(string networkIP)
        {
            string data = textBox1.Text;
            string[] dataSplit = data.Split('/');
            string ip = dataSplit[0];
            int hostBits = Convert.ToInt32(dataSplit[1]);
            string newIP = "".PadLeft(hostBits, '0').PadRight(32, '1');
            string orIP = "";
            string broadcastIP = "";
            for (int i = 0; i < 4; i++)
            {
                string substr = newIP.Substring(i * 8, 8);
                int number = Convert.ToInt32(substr, 2);
                orIP += number + (i == 3 ? "" : ".");
            }
            for (int i = 0; i < 4; i++)
            {
                string[] ipArray1 = networkIP.Split('.');
                string[] ipArray2 = orIP.Split('.');
                int number1 = Convert.ToInt32(ipArray1[i]);
                int number2 = Convert.ToInt32(ipArray2[i]);
                int number3 = number1 | number2;
                broadcastIP += number3 + (i == 3 ? "" : ".");
            }
            return broadcastIP;
        }
        public int getAvailableIPCount()
        {
            string data = textBox1.Text;
            string[] dataSplit = data.Split('/');
            string ip = dataSplit[0];
            int hostBits = Convert.ToInt32(dataSplit[1]);
            return (int)Math.Pow(2, 32 - hostBits) - 2;
        }
    }
}
