﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _100pA
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        List<Point> pointList = new List<Point>();

        private void button1_Click(object sender, EventArgs e)
        {
            int n = Convert.ToInt32(textBox1.Text); //把n的值讀進來
            String colorName = comboBox1.Text; //把使用者選定的顏色名稱讀進來
            Bitmap bmp = new Bitmap(pictureBox1.Width, pictureBox1.Height); //建立一個新的bitmap類別，長度與寬度與picturebox1一樣
            Graphics graphic = Graphics.FromImage(bmp); //建立一個Graphic類別，匯入bmp
            Dictionary<String, Pen> color = new Dictionary<string, Pen>(); //建立Dictionary類別，用來根據使用者選定的顏色名稱選擇畫筆顏色

            graphic.Clear(Color.White); //初始化bmp
            pointList.Clear(); //清除掉pointList            
            color.Add("R", Pens.Red); //建立查詢，當查詢為R時給予紅色的畫筆物件
            color.Add("B", Pens.Black); //建立查詢，當查詢為B時給予黑色的畫筆物件
            color.Add("G", Pens.Green); //建立查詢，當查詢為G時給予綠色的畫筆物件
            color.Add("L", Pens.Blue); //建立查詢，當查詢為L時給予藍色的畫筆物件
            for (int i = 0; i < n; i++)
            {
                double x = 300 * Math.Cos(i * ((2 * Math.PI) / n)) + (pictureBox1.Width / 2);
                double y = 300 * Math.Sin(i * ((2 * Math.PI) / n)) + (pictureBox1.Height / 2);
                Point point = new Point((int)x, (int)y);
                //graphic.FillEllipse(Brushes.Black, (int)x, (int)y, 5, 5);
                pointList.Add(point); //把點存起來，等等畫圖用
            }           
            for (int i = 0; i < pointList.Count; i++)
            {
                for(int j = 0; j < pointList.Count; j++)
                {
                    graphic.DrawLine(color[colorName], pointList[i], pointList[j]); //畫線
                }
            }
            pictureBox1.Image = bmp; //把畫完的圖片呈現在pictureBox1上
        }
    }
}
