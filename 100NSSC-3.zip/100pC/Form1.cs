﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _100pC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int totalSecond = 0;

        private void button1_Click(object sender, EventArgs e)
        {
            string strMinutes = textBox1.Text;
            string strSeconds = textBox2.Text;
            int minutes = Convert.ToInt32(strMinutes);
            int seconds = Convert.ToInt32(strSeconds);
            totalSecond = minutes * 60 + seconds;
            timer1.Enabled = true;
            timer1.Interval = 1000;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            int minutes = totalSecond / 60;
            int seconds = totalSecond % 60;
            textBox1.Text = Convert.ToString(minutes).PadLeft(2,'0');
            textBox2.Text = Convert.ToString(seconds).PadLeft(2, '0');
            if (totalSecond == 0)
            {
                timer1.Enabled = false;
                MessageBox.Show("時間到");
            }
            totalSecond--;
        }
    }
}
